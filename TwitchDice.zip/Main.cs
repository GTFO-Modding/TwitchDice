﻿using System;
using BepInEx;
using BepInEx.IL2CPP;
using BepInEx.Logging;
using CellMenu;
using HarmonyLib;
using TwitchDice.Twitch;
using UnhollowerRuntimeLib;
using UnityEngine;

namespace TwitchDice
{
    [BepInPlugin(GUID, NAME, VERSION)]
    public class Main : BasePlugin
    {
        public const string
            NAME = "TwitchDice",
            AUTHOR = "dak",
            VERSION = "1.0.0",
            GUID = "com." + AUTHOR + "." + NAME;

        public static ManualLogSource log;

        public override void Load()
        {
            log = Log;
            new TwitchManager();
            ClassInjector.RegisterTypeInIl2Cpp<DiceMaster>();

            var harmony = new Harmony(GUID);

            var hotReloadInjectPoint = typeof(CM_PageRundown_New).GetMethod("OnEnable");
            var diceMaster = typeof(Main).GetMethod("CreateDiceMaster");
            harmony.Patch(hotReloadInjectPoint, null, new HarmonyMethod(diceMaster));

            harmony.PatchAll();
        }




        public static void CreateDiceMaster()
        {
            GameObject gameObject = new GameObject();
            gameObject.AddComponent<DiceMaster>();
            UnityEngine.Object.DontDestroyOnLoad(gameObject);
        }
    }
}
