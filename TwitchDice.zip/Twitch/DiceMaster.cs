﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace TwitchDice.Twitch
{
    class DiceMaster : MonoBehaviour
    {
        public DiceMaster(IntPtr intPtr) : base(intPtr) { }
        public TwitchManager TwitchManager;
        void Awake()
        {
            TwitchManager = new TwitchManager();

            if (!TwitchManager.IsConnected)
            {
                TwitchManager.Connect("", "", "", "");
            }
        }

    }
}
